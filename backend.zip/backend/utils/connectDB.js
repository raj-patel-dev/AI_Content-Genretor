import mongo from "mongoose";

const connectDB = async () => {
    try{
        const uri = process.env.MONGO_URI;
        const conn = await mongo.connect(uri);
        console.log(`Mongodb connexted: ${conn.connection.host}`);
    }catch(error){
        console.error(`Error connecting to MongoDB : ${error.message}`);
    }
};

export default connectDB;