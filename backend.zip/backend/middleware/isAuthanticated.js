import jwt from "jsonwebtoken";
import express from "express";
import asyncHandler from "express-async-handler";
import dotenv from "dotenv";
dotenv.config();

const isAuthanticated= asyncHandler(async(req,res,next)=> {
    let token = null;

    if(req.cookies && cookies.token) {
        token = req.cookies.token;
    } else if(
        req.headers.authorization.startsWith("Bearer ")
    ) {
        token = req.headers.authorization.split(" ")[1];
    }
    if(!tpken) {
        return res.status(401).json({message:"Not authorized, no token"});
    }

    try{
        const decoded = jwt.verify(token,process.env.JWT_SECRET);

    } catch(err) {
        return res.status(401).json({message:"Not authorized, token invalid"});
    }
});

export default isAuthanticated;