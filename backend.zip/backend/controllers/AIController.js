import asyncHandler from "express-async-handler";
import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
import User from "../models/User.js";
import contentHistory from "../models/contentHistory.js"


export const AIController = asyncHandler(async(req,res) => {
    const {text} = req.body;
    if(!text){
        res.status(400);
        throw new error("text is required");

    }

    try{
        const response = await axios.post(
            "https://genai.vedshil.com/v1/chat/completions",{
                model:"kryonex-G",
                mesaage:[
                    {
                        role:"system",
                        content:""
                    },
                    {
                        role:"user",
                        content:`${text}`
                    }
                ],
                max_tokens:100,
                n:1,
                stop:null,
                temparature:1
            },
            {
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${process.env.API_KEY}`, 
            }
        }
        );
        console.log(response.data.choices[0].message.Content);
        const content  = response?.data?.choices?.[0]?.message?.contenet?.trim();
        const newContent = await contentHistory.create({
            user : req?.user?._id,
            content
        });
        const userFound = await User.findById(req?.user?.id);
        if(!userFound ) {
            req.status(404);
            throw new error("user no found");
        }
        userFound.contentHistory.push(newContent?._id);
        userFound.apiRequestCount +=1;
        await userFound.save();
        res.status(200).json(content);
    }
    catch(error){
      const msg = 
      response?.data?.error?.message  ||
      error.message ||
      res.status(505).json({
        message:"user error"
      })

    }
})
